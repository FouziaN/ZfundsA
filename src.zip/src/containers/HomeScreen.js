import React, {Component} from 'react';
import {SafeAreaView, Text, StyleSheet, View, ScrollView} from 'react-native';
import Header from '../components/Header';
import HeaderCards from '../components/HeaderCards';
import Colors from '../constants/Colors';

const items = [
  {
    id: 1,
    title: 'Nippon India Balanced',
    type: 'Advantage Fund-Growth Plan-G',
    raiting: 3,
    first_percentage: 28,
    second_percentage: 11,
    third_percentage: 11.1,
  },
  {
    id: 2,
    title: 'Edelwise Balaced Advantage',
    type: 'Fund-Regular Plan-Growth',
    raiting: 5,
    first_percentage: 29.4,
    second_percentage: 13.2,
    third_percentage: 12.3,
  },
  {
    id: 3,
    title: 'HDFC Balanced Advantage',
    type: 'Fund-Growth Plan',
    raiting: 0,
    first_percentage: 45,
    second_percentage: 13.2,
    third_percentage: 12.8,
  },
  {
    id: 4,
    title: 'ICIC Prudential Equity & Debt',
    type: 'Fund-Growth',
    raiting: 3,
    first_percentage: 46.5,
    second_percentage: 14.8,
    third_percentage: 13.3,
  },
  {
    id: 5,
    title: 'SBI Equity Hybrid Fund-',
    type: 'Regular Plan-Growth',
    raiting: 4,
    first_percentage: 33.9,
    second_percentage: 13.8,
    third_percentage: 12.8,
  },
];

export class HomeScreen extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Header />
        <ScrollView>
          <Text
            style={{
              fontSize: 17,
              fontWeight: '600',
              color: Colors.darkBlue,
              marginTop: 15,
              marginLeft: 10,
            }}>
            Popular Funds
          </Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            pagingEnabled>
            {items.map(item => {
              return (
                <HeaderCards
                  title={item.title}
                  type={item.type}
                  raiting={item.raiting}
                  first_percentage={item.first_percentage}
                  second_percentage={item.second_percentage}
                  third_percentage={item.third_percentage}
                />
              );
            })}
          </ScrollView>
          <Text
            style={{
              fontSize: 17,
              fontWeight: '600',
              color: Colors.darkBlue,
              marginTop: 15,
              marginLeft: 10,
            }}>
            Collections
          </Text>
        </ScrollView>
      </View>
    );
  }
}

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
  },
});
