import React, {Component} from 'react';
import {Image, ScrollView, Text, View} from 'react-native';
import CustomButton from '../components/CustomButton';
import Header from '../components/Header';
import Colors from '../constants/Colors';
import Images from '../constants/Images';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icons from 'react-native-vector-icons/AntDesign';

export class ProfileScreen extends Component {
  render() {
    return (
      <View style={{flex: 1, backgroundColor: 'white'}}>
        <Header />
        <ScrollView>
          <Text
            style={{
              fontSize: 16,
              fontWeight: '600',
              color: Colors.darkBlue,
              marginTop: 15,
              marginLeft: 15,
            }}>
            Your ZF Expert
          </Text>
          <View
            style={{
              height: 150,
              backgroundColor: '#eff7fa',
              borderRadius: 10,
              marginLeft: '3%',
              marginRight: '3%',
              marginTop: '3%',
              padding: 14,
            }}>
            <View style={{flexDirection: 'row'}}>
              <Image
                source={Images.profile}
                style={{
                  height: 50,
                  width: 50,
                  borderRadius: 50 / 2,
                  backgroundColor: 'black',
                }}
              />

              <View style={{marginLeft: 15, marginTop: 5}}>
                <Text
                  style={{
                    fontSize: 17,
                    fontWeight: '700',
                    color: Colors.darkBlue,
                  }}>
                  ZFUNDS TEAM
                </Text>
                <View style={{borderWidth: 0.5, color: 'grey'}} />
                <Text
                  style={{
                    fontSize: 12,
                    fontWeight: '400',
                    color: Colors.darkBlue,
                  }}>
                  Retirement_Planning | Financial_Planning | Goal_Planning
                </Text>
              </View>
            </View>
            <View
              style={{
                justifyContent: 'space-around',
                flexDirection: 'row',
                marginTop: 30,
              }}>
              <CustomButton
                customStyles={{width: 160, borderWidth: 1, borderRadius: 5}}
                title="Call Advisor"
                customText={{color: Colors.darkBlue, fontWeight: '500'}}
              />
              <CustomButton
                customStyles={{
                  width: 160,
                  borderWidth: 1,
                  borderRadius: 5,
                  backgroundColor: Colors.darkBlue,
                }}
                title="WhatsApp Advisor"
                customText={{color: Colors.white, fontWeight: '500'}}
              />
            </View>
          </View>
          <Text
            style={{
              fontSize: 16,
              fontWeight: '600',
              color: Colors.darkBlue,
              marginTop: 20,
              marginLeft: 15,
            }}>
            Your Account
          </Text>
          <View
            style={{
              height: 40,
              backgroundColor: '#eff7fa',
              borderRadius: 10,
              marginLeft: '3%',
              marginRight: '3%',
              marginTop: '3%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: 10,
            }}>
            <Icon name="hammer-screwdriver" size={20} color={'#052F5F'} />
            <Text style={{marginRight: 160, color: Colors.darkBlue}}>
              Help and Support
            </Text>
            <Icon name="chevron-right" size={22} color={'#052F5F'} />
          </View>
          <View
            style={{
              height: 40,
              backgroundColor: '#eff7fa',
              borderRadius: 10,
              marginLeft: '3%',
              marginRight: '3%',
              marginTop: '3%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: 10,
            }}>
            <Icons name="questioncircleo" size={20} color={'#052F5F'} />
            <Text style={{marginRight: 180, color: Colors.darkBlue}}>
              About ZFunds
            </Text>
            <Icon name="chevron-right" size={22} color={'#052F5F'} />
          </View>
          <View
            style={{
              height: 40,
              backgroundColor: '#eff7fa',
              borderRadius: 10,
              marginLeft: '3%',
              marginRight: '3%',
              marginTop: '3%',
              flexDirection: 'row',

              alignItems: 'center',
              padding: 10,
            }}>
            <Icon name="logout" size={20} color={'#052F5F'} />
            <Text style={{marginLeft: 20, color: Colors.darkBlue}}>Logout</Text>
          </View>
        </ScrollView>
      </View>
    );
  }
}

export default ProfileScreen;
