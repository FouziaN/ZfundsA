import React, {Component} from 'react';
import {Image, Text, View} from 'react-native';
import CustomButton from '../components/CustomButton';
import Header from '../components/Header';
import Colors from '../constants/Colors';
import Images from '../constants/Images';

export class PortfolioScreen extends Component {
  render() {
    return (
      <>
        <Header />
        <View
          style={{
            flex: 1,
            backgroundColor: 'white',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <View style={{justifyContent: 'center', alignItems: 'center'}}>
            <Image
              source={Images.emptyPortfolio}
              resizeMode="contain"
              style={{height: 130, marginLeft: 20}}
            />
            <Text
              style={{fontWeight: '600', fontSize: 16, color: Colors.darkBlue}}>
              Empty portfolio !
            </Text>
            <Text style={{fontSize: 14, marginTop: 5, color: Colors.darkBlue}}>
              You don't have any investment
            </Text>
            <CustomButton
              customStyles={{
                backgroundColor: Colors.darkBlue,
                width: 180,
                borderRadius: 5,
                marginTop: 20,
                borderColor: 'green',
                borderWidth: 1,
              }}
              title="Start Investing"
              customText={{color: 'white', fontWeight: '500', fontSize: 14}}
            />
          </View>
        </View>
      </>
    );
  }
}

export default PortfolioScreen;
