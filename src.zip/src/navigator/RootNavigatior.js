import React from 'react';
import {StyleSheet, Text, View, Image} from 'react-native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import HomeScreen from '../containers/HomeScreen';
import PortfolioScreen from '../containers/PortfolioScreen';
import ProfileScreen from '../containers/ProfileScreen';
import Colors from '../constants/Colors';
import Icon from 'react-native-vector-icons/Ionicons';

const Tab = createBottomTabNavigator();

const RootNavigatior = () => {
  return (
    <Tab.Navigator
      tabBarOptions={{
        showLabel: false,
        // Floating Tab Bar...
        style: {
          backgroundColor: Colors.darkBlue,
          position: 'absolute',
          bottom: 40,
          marginHorizontal: 40,
          // Max Height...
          height: 60,
          borderRadius: 10,
        },
      }}>
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarIcon: ({focused}) => (
            <View
              style={{
                // centring Tab Button...
                alignItems: 'center',
                justifyContent: 'center',
                top: 15,
              }}>
              <Icon
                name="compass-sharp"
                size={30}
                color={focused ? 'white' : '#8096af'}
              />
              <Text style={{color: focused ? 'white' : '#8096af'}}>
                Explore
              </Text>
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="PortFolio"
        component={PortfolioScreen}
        options={{
          tabBarIcon: ({focused}) => (
            <View
              style={{
                // centring Tab Button...
                alignItems: 'center',
                justifyContent: 'center',
                top: 15,
              }}>
              <Icon
                name="briefcase"
                size={30}
                color={focused ? 'white' : '#8096af'}></Icon>
              <Text style={{color: focused ? 'white' : '#8096af'}}>
                Portfolio
              </Text>
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          tabBarIcon: ({focused}) => (
            <View
              style={{
                // centring Tab Button...
                alignItems: 'center',
                justifyContent: 'center',
                top: 15,
              }}>
              <Icon
                name="person"
                size={30}
                color={focused ? 'white' : '#8096af'}></Icon>
              <Text style={{color: focused ? 'white' : '#8096af'}}>My App</Text>
            </View>
          ),
        }}
      />
    </Tab.Navigator>
  );
};

export default RootNavigatior;

const styles = StyleSheet.create({});
