export default {
  darkBlue: '#052F5F',
  white: '#fff',
  grey: '#d3d3d3',
};
