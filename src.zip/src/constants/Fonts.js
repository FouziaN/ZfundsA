export default {
  NotoSans_Regular: 'NotoSans-Regular.ttf',
  NotoSans_Bold: 'NotoSans-Bold.ttf',
};
