export default {
  logo: require('../assets/Images/logo.png'),
  emptyPortfolio: require('../assets/Images/portfolio.png'),
  profile: require('../assets/Images/zflogo.png'),
};
