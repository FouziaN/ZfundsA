import React from 'react';
import {TouchableOpacity, View, Text, Image, StyleSheet} from 'react-native';
import {normalize} from '../constants/Dimension';
import Colors from '../constants/Colors';
import Images from '../constants/Images';
import Fonts from '../constants/Fonts';
import Icon from 'react-native-vector-icons/EvilIcons';

const Header = () => {
  return (
    <View style={styles.container}>
      <View style={{flexDirection: 'row', marginRight: 50}}>
        <Image source={Images.logo} style={{height: 30}} resizeMode="contain" />
        <Text
          style={{
            position: 'absolute',
            right: -37,
            top: 3,
            fontSize: 20,
            color: Colors.darkBlue,
          }}>
          UNDS
        </Text>
      </View>
      <View style={{flexDirection: 'row', position: 'absolute', right: 12}}>
        <Icon
          style={{marginRight: 16}}
          name="search"
          size={25}
          color={'#052F5F'}
        />
        <Icon name="cart" size={25} color={'#052F5F'} />
      </View>
    </View>
  );
};
export default Header;

const styles = StyleSheet.create({
  container: {
    borderBottomWidth: normalize(1),
    marginTop: normalize(30),
    borderBottomColor: Colors.grey,
    backgroundColor: Colors.white,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    shadowColor: 'black',
    shadowOffset: {width: 0, height: 2},
    shadowRadius: 2,
    shadowOpacity: 0.1,
    elevation: 3,
  },
});
