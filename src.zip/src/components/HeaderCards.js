import React from 'react';
import {StyleSheet, Text, View, Dimensions} from 'react-native';
import Icon from 'react-native-vector-icons/Entypo';
import Colors from '../constants/Colors';

const SCREEN_WIDTH = Dimensions.get('screen').width;

const HeaderCards = React.memo(
  function HeaderCards(props) {
    return (
      <View
        width={SCREEN_WIDTH * 0.8}
        style={{
          backgroundColor: '#eff7fa',
          height: 130,
          borderWidth: 1,
          borderColor: '#d3d3d3',

          borderRadius: 10,
          marginLeft: 15,
          marginTop: 10,
        }}>
        <View style={{flexDirection: 'row', margin: 20}}>
          <View>
            <Text
              style={{fontWeight: '700', color: Colors.darkBlue, fontSize: 15}}>
              {props.title}
            </Text>
            <Text
              style={{fontWeight: '700', color: Colors.darkBlue, fontSize: 15}}>
              {props.type}
            </Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              height: 20,
              width: 25,
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor: '#bfe6ff',
              borderRadius: 5,
              position: 'absolute',
              right: 0,
            }}>
            <Icon name="star" color={'#fed000'} />
            <Text>{props.raiting}</Text>
          </View>
        </View>
        <View style={{borderWidth: 0.5, opacity: 0.5, borderColor: 'grey'}} />
        <View
          style={{
            padding: 10,
            flexDirection: 'row',
            justifyContent: 'space-between',
          }}>
          <View style={{alignItems: 'center'}}>
            <Text style={{fontSize: 11}}>1 yr Return</Text>
            <Text
              style={{fontSize: 13, color: Colors.darkBlue, fontWeight: '700'}}>
              {props.first_percentage}%
            </Text>
          </View>
          <View style={{alignItems: 'center'}}>
            <Text style={{fontSize: 11}}>3 yr Return</Text>
            <Text
              style={{fontSize: 13, color: Colors.darkBlue, fontWeight: '700'}}>
              {props.second_percentage}%
            </Text>
          </View>
          <View style={{alignItems: 'center'}}>
            <Text style={{fontSize: 11}}>5 yr Return</Text>
            <Text
              style={{fontSize: 13, color: Colors.darkBlue, fontWeight: '700'}}>
              {props.third_percentage}%
            </Text>
          </View>
        </View>
      </View>
    );
  },
  () => true,
);

export default HeaderCards;

const styles = StyleSheet.create({});
